# Collaborative

This plugin adds collaborative functionallity to Codiad

# Installation

- Download the zip file and extract it to your plugins folder
